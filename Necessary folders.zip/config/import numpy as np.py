import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# Define the positions of the planets (x, y, z)
planets = {
    'Mercury': [0.39, 0, 0],
    'Venus': [0.72, 0, 0],
    'Earth': [1.0, 0, 0],
    'Mars': [1.52, 0, 0],
    'Jupiter': [5.2, 0, 0],
    'Saturn': [9.58, 0, 0],
    'Uranus': [19.22, 0, 0],
    'Neptune': [30.05, 0, 0]
}

fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

# Plot each planet
for planet, position in planets.items():
    ax.scatter(position[0], position[1], position[2], label=planet)

# Set labels
ax.set_xlabel('X Position (AU)')
ax.set_ylabel('Y Position (AU)')
ax.set_zlabel('Z Position (AU)')
ax.set_title('3D Solar System Model')
ax.legend()

plt.show()


### MATLAB Code

planets = struct('Mercury', [0.39, 0, 0], ...
                 'Venus', [0.72, 0, 0], ...
                 'Earth', [1.0, 0, 0], ...
                 'Mars', [1.52, 0, 0], ...
                 'Jupiter', [5.2, 0, 0], ...
                 'Saturn', [9.58, 0, 0], ...
                 'Uranus', [19.22, 0, 0], ...
                 'Neptune', [30.05, 0, 0]);

figure;
hold on;

% Plot each planet
fields = fieldnames(planets);
for i = 1:length(fields)
    planet = fields{i};
    position = planets.(planet);
    plot3(position(1), position(2), position(3), 'o', 'DisplayName', planet);
end

% Set labels
xlabel('X Position (AU)');
ylabel('Y Position (AU)');
zlabel('Z Position (AU)');
title('3D Solar System Model');
legend show;
grid on;
hold off;