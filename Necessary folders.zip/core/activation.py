"""
Trinity Activation
Loads config, validates each provider, and reports combined status.
"""

from core.config_loader import load_config, get_api_key, is_provider_enabled, mask_key
from core.status import ProviderStatus, print_trinity_header, print_status_report, print_missing_warning
from providers.openai_provider import validate_openai
from providers.anthropic_provider import validate_anthropic
from providers.gemini_provider import validate_gemini


PLACEHOLDER_FRAGMENTS = {
    "your", "placeholder", "insert", "example", "sample", "demo", "dummy",
    "changeme", "change-me", "paste", "replace", "api_key", "apikey",
}

EXACT_PLACEHOLDERS = {
    "", "test", "abc", "xxx", "your-key-here", "insert-key", "sk-...",
    "sk-ant-...", "aiza...", "your_openai_api_key_here",
    "your_anthropic_api_key_here", "your_gemini_api_key_here",
}


VALIDATORS = {
    "openai":    validate_openai,
    "anthropic": validate_anthropic,
    "gemini":    validate_gemini,
}


def _looks_configured_key(key: str, provider: str) -> bool:
    """
    Cheap local sanity check before making a network call.
    Catches blanks, placeholders, obvious examples, and too-short values.
    This is not meant to prove the key is valid. Live provider validation does that.
    """
    if not key:
        return False

    cleaned = str(key).strip()
    lowered = cleaned.lower()

    if lowered in EXACT_PLACEHOLDERS:
        return False

    if "..." in cleaned:
        return False

    if any(fragment in lowered for fragment in PLACEHOLDER_FRAGMENTS):
        return False

    if len(cleaned) < 20:
        return False

    # Provider-specific light checks. These are intentionally not too strict because
    # providers can change formats over time.
    if provider == "openai" and not cleaned.startswith("sk-"):
        return False

    if provider == "anthropic" and not cleaned.startswith("sk-ant-"):
        return False

    if provider == "gemini" and not cleaned.startswith("AIza"):
        return False

    return True


def run_activation(dry_run: bool = False) -> dict:
    """
    Full startup activation sequence.
    Returns results dict: { provider: (ProviderStatus, note) }

    dry_run=True checks local config structure and key shape without calling APIs.
    """
    print_trinity_header()
    print("[Trinity] Loading config/api_keys.json...\n")

    if dry_run:
        print("[Trinity] Dry run enabled. Provider APIs will not be called.\n")

    config  = load_config()
    results = {}
    missing = []

    for provider, validator in VALIDATORS.items():

        if not is_provider_enabled(config, provider):
            results[provider] = (ProviderStatus.DISABLED, "disabled in config")
            continue

        key = get_api_key(config, provider)

        if not _looks_configured_key(key, provider):
            results[provider] = (ProviderStatus.MISSING, "add a real key to config/api_keys.json")
            missing.append(provider)
            continue

        masked = mask_key(key)

        if dry_run:
            results[provider] = (ProviderStatus.UNTESTED, f"key format looks configured ({masked}); live test skipped")
            continue

        # Key exists — run a minimal live test
        print(f"[Trinity] Testing {provider} ({masked}) ...")
        status, note = validator(key)
        results[provider] = (status, note)

    print()
    print_status_report(results)
    print_missing_warning(missing)

    all_missing = all(s == ProviderStatus.MISSING for s, _ in results.values())
    if all_missing:
        print("[Trinity] No providers configured. Trinity cannot run until at least one key is added.\n")
    else:
        valid_count = sum(1 for s, _ in results.values() if s == ProviderStatus.VALID)
        untested_count = sum(1 for s, _ in results.values() if s == ProviderStatus.UNTESTED)
        if dry_run:
            print(f"[Trinity] Dry run complete. {untested_count} provider key(s) look configured but were not live-tested.\n")
        else:
            print(f"[Trinity] {valid_count} of {len(VALIDATORS)} provider(s) ready.\n")

    return results
