"""
Trinity Config Loader
Handles reading and writing config/api_keys.json.
Primary key source — no environment variables required.
"""

import json
import os
from copy import deepcopy
from typing import Any

CONFIG_PATH = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "config", "api_keys.json")
)

# Model migration map for stale defaults that may exist in older saved configs.
OLD_CLAUDE_HAIKU_ALIAS = "claude-" + "3-5-haiku-latest"
MODEL_ALIASES = {
    OLD_CLAUDE_HAIKU_ALIAS: "claude-haiku-4-5-20251001",
    "gemini-2.5-flash-latest": "gemini-2.5-flash-lite",
}

DEFAULT_CONFIG = {
    "openai": {
        "api_key": "",
        "enabled": True,
        "model": "gpt-4o-mini"
    },
    "anthropic": {
        "api_key": "",
        "enabled": True,
        "model": "claude-haiku-4-5-20251001"
    },
    "gemini": {
        "api_key": "",
        "enabled": True,
        "model": "gemini-2.5-flash-lite"
    },
    "trinity": {
        "mode": "auto",
        "dev_log": True,
        "log_folder": "logs",
        "simple_prompt_word_limit": 12,
        "max_creative_tokens": 120,
        "max_checker_tokens": 80,
        "max_final_tokens": 750,
        "data_folder": "data",
        "enable_web_grounding": True,
        "max_source_results": 5,
        "accepted_source_limit": 3,
        "source_timeout_seconds": 10,
        "parallel_tool_limit": 5,
        "use_claude_grounded_checker": True
    }
}


def _ensure_config_dir() -> None:
    config_dir = os.path.dirname(CONFIG_PATH)
    os.makedirs(config_dir, exist_ok=True)


def save_config(config: dict[str, Any]) -> None:
    """Safely write config/api_keys.json back to disk."""
    _ensure_config_dir()
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=4)
        f.write("\n")


def create_default_config() -> dict[str, Any]:
    """Create a blank config file if one does not exist and return it."""
    config = deepcopy(DEFAULT_CONFIG)
    save_config(config)
    print("[Trinity] config/api_keys.json created. Open it and add your API keys, then run Trinity again.")
    return config


def _normalize_provider_block(config: dict[str, Any], provider: str) -> bool:
    """
    Ensure a provider block exists and contains all required fields.
    Returns True if the config was repaired.
    """
    repaired = False
    defaults = DEFAULT_CONFIG[provider]

    if provider not in config or not isinstance(config.get(provider), dict):
        config[provider] = deepcopy(defaults)
        return True

    for field, value in defaults.items():
        if field not in config[provider]:
            config[provider][field] = value
            repaired = True

    # Keep enabled as a real boolean even if someone typed "true" / "false" in JSON as a string.
    enabled_value = config[provider].get("enabled", True)
    if isinstance(enabled_value, str):
        config[provider]["enabled"] = enabled_value.strip().lower() not in {"false", "0", "no", "off"}
        repaired = True

    # Migrate stale model aliases from older Trinity builds.
    model_value = config[provider].get("model")
    if isinstance(model_value, str) and model_value in MODEL_ALIASES:
        config[provider]["model"] = MODEL_ALIASES[model_value]
        repaired = True

    return repaired


def load_config() -> dict[str, Any]:
    """
    Load API keys from config/api_keys.json.
    Creates the file if it does not exist.
    Repairs missing provider fields and saves those repairs back to disk.
    Returns the parsed config dict.
    """
    _ensure_config_dir()

    if not os.path.exists(CONFIG_PATH):
        return create_default_config()

    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            config = json.load(f)
    except json.JSONDecodeError as e:
        print(f"[Trinity] ERROR: config/api_keys.json is not valid JSON. {e}")
        print("[Trinity] Fix the file and run Trinity again.")
        return deepcopy(DEFAULT_CONFIG)

    if not isinstance(config, dict):
        print("[Trinity] ERROR: config/api_keys.json must contain a JSON object at the top level.")
        print("[Trinity] Fix the file and run Trinity again.")
        return deepcopy(DEFAULT_CONFIG)

    repaired = False
    for provider in ["openai", "anthropic", "gemini", "trinity"]:
        repaired = _normalize_provider_block(config, provider) or repaired

    if repaired:
        save_config(config)
        print("[Trinity] Repaired missing config fields in config/api_keys.json.")

    return config


def get_api_key(config: dict, provider: str) -> str:
    """Return the raw API key for a provider, or empty string."""
    value = config.get(provider, {}).get("api_key", "")
    return str(value).strip()


def is_provider_enabled(config: dict, provider: str) -> bool:
    """Return True if the provider is enabled in config."""
    return bool(config.get(provider, {}).get("enabled", True))


def mask_key(key: str) -> str:
    """Return a masked version of the key for safe terminal display."""
    key = str(key).strip()
    if not key or len(key) < 8:
        return "[too short to mask]"
    return f"{key[:4]}...{key[-4:]}"
