"""
Trinity V1.5 — Tool-Grounded Economical Orchestration

Core design:
- Python is the real orchestrator: routing, tools, source checks, CSV retention,
  prompt construction, parsing, fallbacks, logging, and session dumps.
- GPT/OpenAI is the lead final writer.
- Claude/Anthropic is the concise reasoning/safety/grounding checker.
- Gemini is ONLY used when the task needs creative/imaginative expansion.

The dev log records visible prompts/outputs only. It does NOT expose private
hidden reasoning from any provider.
"""

from __future__ import annotations

import ast
import csv
import json
import math
import os
import re
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import quote_plus, urlparse

from core.config_loader import get_api_key, is_provider_enabled
from core.status import ProviderStatus, Color

CHEAP_DEFAULTS = {
    "mode": "auto",
    "openai_model": "gpt-4o-mini",
    "anthropic_model": "claude-haiku-4-5-20251001",
    "gemini_models": [
        "gemini-2.5-flash-lite",
        "gemini-1.5-flash-latest",
        "gemini-2.5-flash",
        "gemini-2.0-flash",
    ],
    "simple_prompt_word_limit": 12,
    "max_creative_tokens": 120,
    "max_checker_tokens": 80,
    "max_final_tokens": 750,
    "temperature_creative": 0.4,
    "temperature_checker": 0.0,
    "temperature_final": 0.2,
    "log_folder": "logs",
    "data_folder": "data",
    "dev_log": True,
    "enable_web_grounding": True,
    "max_source_results": 5,
    "accepted_source_limit": 3,
    "source_timeout_seconds": 10,
    "parallel_tool_limit": 5,
    "use_claude_grounded_checker": True,
}

EXIT_COMMANDS = {"exit", "quit", "q"}

CREATIVE_KEYWORDS = [
    "creative", "brainstorm", "ideas", "name", "logo", "image", "poster",
    "storyboard", "script", "pitch", "design", "theme", "original", "video",
    "animation", "visual", "flow chart", "flowchart", "diagram", "brand",
    "slogan", "tagline", "generate", "imagine", "concept", "mockup",
]

FACTUAL_KEYWORDS = [
    "what is", "explain", "lore", "history", "current", "latest", "price",
    "release", "law", "news", "compare", "review", "source", "citation",
    "facts", "data", "research", "who is", "when did", "where is", "why did",
    "implications", "case study", "statistics", "evidence", "according to",
]

STANDARD_COMPLEX_KEYWORDS = [
    "plan", "roadmap", "architecture", "strategy", "build", "justify",
    "pros and cons", "security", "pricing", "workflow", "full thinking",
    "deep", "detailed", "should i", "why would", "how would", "investor",
    "prototype", "orchestration", "trinity", "analyze",
]

STOPWORDS = {
    "the", "and", "for", "that", "this", "with", "what", "when", "where", "why",
    "how", "from", "into", "about", "does", "would", "could", "should", "there",
    "their", "they", "them", "then", "than", "have", "been", "will", "your", "you",
    "are", "was", "were", "its", "it's", "can", "one", "two", "three", "tell", "me",
    "explain", "analyze", "generate", "make", "create", "need", "use", "using",
}


# -----------------------------
# General helpers
# -----------------------------


def _is_quota_error(error_text: str) -> bool:
    lowered = error_text.lower()
    return (
        "429" in lowered
        or "quota" in lowered
        or "rate limit" in lowered
        or "resource exhausted" in lowered
        or "insufficient_quota" in lowered
    )


def _is_model_not_found(error_text: str) -> bool:
    lowered = error_text.lower()
    return (
        "404" in lowered
        or "not found" in lowered
        or "not supported" in lowered
        or ("model" in lowered and "does not exist" in lowered)
    )


def _clean_text(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip()


def _dedupe_keep_order(items: list[str]) -> list[str]:
    seen = set()
    output = []
    for item in items:
        if item and item not in seen:
            output.append(item)
            seen.add(item)
    return output


def _get_trinity_settings(config: dict) -> dict:
    trinity = config.get("trinity", {})
    if not isinstance(trinity, dict):
        trinity = {}

    settings = dict(CHEAP_DEFAULTS)
    settings.update({k: v for k, v in trinity.items() if v is not None})

    settings["openai_model"] = config.get("openai", {}).get("model") or settings["openai_model"]
    settings["anthropic_model"] = config.get("anthropic", {}).get("model") or settings["anthropic_model"]

    gemini_model = config.get("gemini", {}).get("model")
    base_models = list(settings.get("gemini_models", CHEAP_DEFAULTS["gemini_models"]))
    if gemini_model:
        base_models = [gemini_model] + base_models
    bad_models = {"gemini-2.5-flash-latest"}
    settings["gemini_models"] = _dedupe_keep_order([m for m in base_models if m not in bad_models])

    int_keys = [
        "max_creative_tokens", "max_checker_tokens", "max_final_tokens",
        "simple_prompt_word_limit", "max_source_results", "accepted_source_limit",
        "source_timeout_seconds", "parallel_tool_limit",
    ]
    for key in int_keys:
        try:
            settings[key] = int(settings[key])
        except Exception:
            settings[key] = CHEAP_DEFAULTS[key]

    for key in ["dev_log", "enable_web_grounding", "use_claude_grounded_checker"]:
        if isinstance(settings.get(key), str):
            settings[key] = settings[key].strip().lower() not in {"false", "0", "no", "off"}
        else:
            settings[key] = bool(settings.get(key))

    return settings


def _active_valid_providers(config: dict, activation_results: dict) -> list[str]:
    active = []
    for provider in ["openai", "anthropic", "gemini"]:
        status, _note = activation_results.get(provider, (None, ""))
        if is_provider_enabled(config, provider) and status == ProviderStatus.VALID:
            active.append(provider)
    return active


def extract_keywords(text: str, limit: int = 10) -> list[str]:
    words = re.findall(r"[A-Za-z][A-Za-z0-9'\-]{2,}", text.lower())
    scored: dict[str, int] = {}
    for word in words:
        if word in STOPWORDS or len(word) < 3:
            continue
        scored[word] = scored.get(word, 0) + 1

    # Preserve important multi-word proper-looking terms by adding quoted phrase chunks.
    title_terms = re.findall(r"(?:[A-Z][A-Za-z0-9]+(?:[:'’\-][A-Z]?[A-Za-z0-9]+)?)(?:\s+[A-Z][A-Za-z0-9]+(?:[:'’\-][A-Z]?[A-Za-z0-9]+)?){0,4}", text)
    phrases = []
    for term in title_terms:
        cleaned = term.strip()
        if len(cleaned) >= 4 and cleaned.lower() not in STOPWORDS:
            phrases.append(cleaned)

    ranked = sorted(scored.items(), key=lambda kv: (-kv[1], kv[0]))
    keywords = []
    for phrase in phrases:
        if phrase.lower() not in [k.lower() for k in keywords]:
            keywords.append(phrase)
        if len(keywords) >= 3:
            break
    for word, _count in ranked:
        if word not in [k.lower() for k in keywords]:
            keywords.append(word)
        if len(keywords) >= limit:
            break
    return keywords[:limit]


# -----------------------------
# Routing
# -----------------------------


def classify_task(user_prompt: str, settings: dict) -> tuple[str, str, str]:
    """Return (route, cleaned_prompt, reason). Routes: simple, math_tool, grounded, creative, standard."""
    stripped = user_prompt.strip()
    lowered = stripped.lower()

    command_routes = [
        ("/full", "standard", "User forced standard/full GPT+Claude route with /full."),
        ("/creative", "creative", "User forced creative route with /creative."),
        ("/grounded", "grounded", "User forced grounded/source route with /grounded."),
        ("/cheap", "simple", "User forced cheap/simple route with /cheap."),
        ("/math", "math_tool", "User forced Python math tool route with /math."),
    ]
    for prefix, route, reason in command_routes:
        if lowered.startswith(prefix):
            return route, stripped[len(prefix):].strip(), reason

    configured_mode = str(settings.get("mode", "auto")).lower().strip()
    if configured_mode in {"simple", "cheap", "single"}:
        return "simple", stripped, "Config mode is simple/cheap."
    if configured_mode in {"creative"}:
        return "creative", stripped, "Config mode is creative."
    if configured_mode in {"grounded", "sources"}:
        return "grounded", stripped, "Config mode is grounded."
    if configured_mode in {"full", "standard", "trinity_full"}:
        return "standard", stripped, "Config mode is standard/full."

    word_count = len(stripped.split())
    simple_limit = int(settings.get("simple_prompt_word_limit", 12))

    if _looks_like_math(stripped):
        return "math_tool", stripped, "Prompt looks like a calculation/math request."

    if any(keyword in lowered for keyword in CREATIVE_KEYWORDS):
        return "creative", stripped, "Prompt matched creative/imaginative/tool-output keyword."

    if any(keyword in lowered for keyword in FACTUAL_KEYWORDS):
        return "grounded", stripped, "Prompt matched factual/source-grounding keyword."

    if any(keyword in lowered for keyword in STANDARD_COMPLEX_KEYWORDS):
        return "standard", stripped, "Prompt matched planning/reasoning keyword."

    if word_count <= simple_limit:
        return "simple", stripped, f"Prompt has {word_count} words, under simple limit {simple_limit}."

    return "standard", stripped, f"Prompt has {word_count} words; using GPT+Claude standard route."


# Backward-compatible name if older code imports it.
def decide_flow_mode(user_prompt: str, settings: dict) -> tuple[str, str, str]:
    route, cleaned, reason = classify_task(user_prompt, settings)
    if route in {"creative", "grounded", "standard"}:
        return "full", cleaned, reason
    return "simple", cleaned, reason


# -----------------------------
# CSV/session retention
# -----------------------------


class SessionCSVStore:
    def __init__(self, data_folder: str):
        self.data_dir = Path(data_folder)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.session_id = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        self.memory_rows: list[dict[str, Any]] = []
        self.tool_rows: list[dict[str, Any]] = []
        self.source_rows: list[dict[str, Any]] = []
        self._ensure_instruction_profiles()

    def _append_csv(self, filename: str, fieldnames: list[str], row: dict[str, Any]) -> None:
        path = self.data_dir / filename
        exists = path.exists()
        with path.open("a", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            if not exists:
                writer.writeheader()
            writer.writerow({key: row.get(key, "") for key in fieldnames})

    def remember(self, kind: str, value: str, source: str = "python") -> None:
        row = {
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "session_id": self.session_id,
            "kind": kind,
            "value": value,
            "source": source,
        }
        self.memory_rows.append(row)
        self._append_csv("session_memory_active.csv", ["timestamp", "session_id", "kind", "value", "source"], row)

    def log_tool(self, tool: str, status: str, detail: str, elapsed: float = 0.0) -> None:
        row = {
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "session_id": self.session_id,
            "tool": tool,
            "status": status,
            "elapsed_seconds": f"{elapsed:.2f}",
            "detail": detail[:1000],
        }
        self.tool_rows.append(row)
        self._append_csv("tool_runs.csv", ["timestamp", "session_id", "tool", "status", "elapsed_seconds", "detail"], row)

    def log_source(self, source_check: dict[str, Any]) -> None:
        row = {
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "session_id": self.session_id,
            "url": source_check.get("url", ""),
            "domain": source_check.get("domain", ""),
            "title": source_check.get("title", ""),
            "status": source_check.get("status", ""),
            "score": source_check.get("score", ""),
            "accepted": source_check.get("accepted", ""),
            "keyword_hits": ", ".join(source_check.get("keyword_hits", []) or []),
            "reason": source_check.get("reason", ""),
        }
        self.source_rows.append(row)
        self._append_csv("source_checks.csv", ["timestamp", "session_id", "url", "domain", "title", "status", "score", "accepted", "keyword_hits", "reason"], row)

    def dump_on_exit(self) -> Path:
        dump_path = self.data_dir / f"session_dump_{self.session_id}.csv"
        fieldnames = ["timestamp", "session_id", "kind", "value", "source"]
        with dump_path.open("w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for row in self.memory_rows:
                writer.writerow(row)

        # Clear active memory file for the next session, but keep dump/tool/source history.
        active_path = self.data_dir / "session_memory_active.csv"
        with active_path.open("w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
        return dump_path

    def _ensure_instruction_profiles(self) -> None:
        path = self.data_dir / "instruction_profiles.csv"
        if path.exists():
            return
        rows = [
            {"route": "simple", "gemini": "skip", "claude": "skip", "gpt": "direct concise answer", "python_tools": "routing, csv log", "purpose": "fast cheap replies"},
            {"route": "math_tool", "gemini": "skip", "claude": "skip", "gpt": "explain if needed", "python_tools": "safe calculator, csv log", "purpose": "avoid AI arithmetic"},
            {"route": "grounded", "gemini": "skip", "claude": "short JSON final checker", "gpt": "source-grounded synthesis", "python_tools": "keyword extraction, web search, URL fetch, source verify", "purpose": "reduce hallucinations"},
            {"route": "creative", "gemini": "creative ideas only", "claude": "short JSON checker", "gpt": "final synthesis", "python_tools": "routing, optional format guidance", "purpose": "imagination, design, storyboards, diagrams"},
            {"route": "standard", "gemini": "skip", "claude": "short JSON checker", "gpt": "final synthesis", "python_tools": "routing, session keywords", "purpose": "planning/reasoning without extra creative model"},
        ]
        with path.open("w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=["route", "gemini", "claude", "gpt", "python_tools", "purpose"])
            writer.writeheader()
            writer.writerows(rows)


# -----------------------------
# Dev logging
# -----------------------------


class TrinityDevLogger:
    def __init__(self, log_folder: str, enabled: bool = True):
        self.enabled = bool(enabled)
        self.started_at = datetime.now()
        self.path: Path | None = None

        if self.enabled:
            folder = Path(log_folder)
            folder.mkdir(parents=True, exist_ok=True)
            timestamp = self.started_at.strftime("%Y-%m-%d_%H-%M-%S")
            self.path = folder / f"trinityflow_{timestamp}.txt"
            self.write("TRINITYFLOW V1.5 DEV LOG")
            self.write("=" * 72)
            self.write(f"Started: {self.started_at.isoformat(timespec='seconds')}")
            self.write("Note: This log records visible prompts/outputs only, not private hidden reasoning.")
            self.write("")

    def write(self, text: str = "") -> None:
        if not self.enabled or self.path is None:
            return
        with self.path.open("a", encoding="utf-8") as f:
            f.write(str(text) + "\n")

    def section(self, title: str) -> None:
        self.write("")
        self.write("-" * 72)
        self.write(title)
        self.write("-" * 72)

    def block(self, title: str, content: str) -> None:
        self.write(f"\n{title}:")
        self.write(content if content else "[empty]")


# -----------------------------
# Python tools
# -----------------------------


def _looks_like_math(text: str) -> bool:
    lowered = text.lower()
    if any(word in lowered for word in ["calculate", "solve", "equation", "derivative", "integral", "graph"]):
        return True
    return bool(re.fullmatch(r"[\d\s\.\+\-\*\/\(\)\^%]+", text.strip()))


_ALLOWED_AST_NODES = (
    ast.Expression, ast.BinOp, ast.UnaryOp, ast.Num, ast.Constant,
    ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Pow, ast.Mod, ast.USub, ast.UAdd,
    ast.FloorDiv, ast.Load,
)


def safe_calculate(expression: str) -> str:
    expr = expression.strip().replace("^", "**")
    expr = re.sub(r"(?i)^(what is|calculate|solve)\s+", "", expr).strip().rstrip("?")
    tree = ast.parse(expr, mode="eval")
    for node in ast.walk(tree):
        if not isinstance(node, _ALLOWED_AST_NODES):
            raise ValueError("Unsupported math expression for safe calculator.")
    result = eval(compile(tree, "<trinity_math>", "eval"), {"__builtins__": {}}, {"sqrt": math.sqrt})
    return f"{expr} = {result}"


def web_search_duckduckgo(query: str, max_results: int, timeout: int) -> list[dict[str, str]]:
    try:
        import requests
        from bs4 import BeautifulSoup
    except ImportError as exc:
        raise RuntimeError("Install web grounding packages: pip install requests beautifulsoup4") from exc

    url = f"https://duckduckgo.com/html/?q={quote_plus(query)}"
    headers = {"User-Agent": "Mozilla/5.0 TrinityV1.5"}
    response = requests.get(url, headers=headers, timeout=timeout)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, "html.parser")
    results = []
    for a in soup.select("a.result__a")[:max_results]:
        title = a.get_text(" ", strip=True)
        href = a.get("href", "")
        if not href:
            continue
        results.append({"title": title, "url": href})
    return results


def fetch_url_text(url: str, timeout: int) -> dict[str, str]:
    import requests
    from bs4 import BeautifulSoup

    headers = {"User-Agent": "Mozilla/5.0 TrinityV1.5"}
    response = requests.get(url, headers=headers, timeout=timeout)
    status = response.status_code
    content_type = response.headers.get("content-type", "")
    if "text/html" not in content_type and "application/xhtml" not in content_type:
        return {"url": url, "status": str(status), "title": "", "text": "", "content_type": content_type}

    soup = BeautifulSoup(response.text, "html.parser")
    for tag in soup(["script", "style", "nav", "footer", "aside"]):
        tag.decompose()
    title = soup.title.get_text(" ", strip=True) if soup.title else ""
    headings = " ".join(h.get_text(" ", strip=True) for h in soup.find_all(["h1", "h2", "h3"])[:8])
    body = soup.get_text(" ", strip=True)
    text = (headings + " " + body)[:12000]
    return {"url": url, "status": str(status), "title": title, "text": text, "content_type": content_type}


def verify_source(page: dict[str, str], keywords: list[str]) -> dict[str, Any]:
    url = page.get("url", "")
    parsed = urlparse(url)
    domain = parsed.netloc.lower()
    title = page.get("title", "")
    text = page.get("text", "") or ""
    haystack = f"{url} {title} {text}".lower()

    hits = []
    for kw in keywords:
        if kw.lower() in haystack:
            hits.append(kw)

    domain_bonus = 0.5 if any(d in domain for d in ["wikipedia.org", "developer", "docs", "gov", "edu", "bethesda", "idsoftware", "openai", "anthropic", "google"]) else 0
    score = len(hits) + domain_bonus
    accepted = page.get("status", "") == "200" and score >= min(3, max(1, len(keywords) // 3)) and bool(text)
    reason = "Keyword/title/body match." if accepted else "Rejected: weak keyword match or no readable text."

    return {
        "url": url,
        "domain": domain,
        "title": title[:200],
        "status": page.get("status", ""),
        "score": round(score, 2),
        "accepted": accepted,
        "keyword_hits": hits[:10],
        "reason": reason,
        "snippet": text[:1200],
    }


def collect_grounding_sources(user_prompt: str, settings: dict, store: SessionCSVStore, logger: TrinityDevLogger) -> dict[str, Any]:
    started = time.time()
    keywords = extract_keywords(user_prompt, limit=10)
    query = " ".join(keywords[:6]) or user_prompt
    max_results = int(settings.get("max_source_results", 5))
    timeout = int(settings.get("source_timeout_seconds", 10))
    accepted_limit = int(settings.get("accepted_source_limit", 3))

    logger.section("PYTHON TOOLING - SOURCE GROUNDING")
    logger.write(f"Extracted keywords: {', '.join(keywords)}")
    logger.write(f"Search query: {query}")

    if not settings.get("enable_web_grounding", True):
        logger.write("Web grounding disabled in config.")
        store.log_tool("source_grounding", "skipped", "Web grounding disabled", time.time() - started)
        return {"keywords": keywords, "query": query, "accepted": [], "rejected": [], "error": "disabled"}

    try:
        search_results = web_search_duckduckgo(query, max_results=max_results, timeout=timeout)
        store.log_tool("web_search", "ok", f"{len(search_results)} result(s) for: {query}", time.time() - started)
    except Exception as exc:
        err = str(exc)
        logger.write(f"Search failed: {err}")
        store.log_tool("web_search", "error", err, time.time() - started)
        return {"keywords": keywords, "query": query, "accepted": [], "rejected": [], "error": err}

    checks: list[dict[str, Any]] = []
    rejected: list[dict[str, Any]] = []
    fetch_started = time.time()
    workers = min(int(settings.get("parallel_tool_limit", 5)), max(1, len(search_results)))
    with ThreadPoolExecutor(max_workers=workers) as executor:
        future_map = {executor.submit(fetch_url_text, item["url"], timeout): item for item in search_results}
        for future in as_completed(future_map):
            source_item = future_map[future]
            try:
                page = future.result()
                if not page.get("title"):
                    page["title"] = source_item.get("title", "")
                check = verify_source(page, keywords)
            except Exception as exc:
                check = {
                    "url": source_item.get("url", ""),
                    "domain": urlparse(source_item.get("url", "")).netloc,
                    "title": source_item.get("title", ""),
                    "status": "error",
                    "score": 0,
                    "accepted": False,
                    "keyword_hits": [],
                    "reason": str(exc)[:250],
                    "snippet": "",
                }
            store.log_source(check)
            checks.append(check)

    accepted = sorted([c for c in checks if c.get("accepted")], key=lambda x: x.get("score", 0), reverse=True)[:accepted_limit]
    rejected = [c for c in checks if not c.get("accepted")]

    store.log_tool("fetch_verify_sources", "ok", f"accepted={len(accepted)}, rejected={len(rejected)}", time.time() - fetch_started)
    logger.write(f"Accepted sources: {len(accepted)}")
    for idx, src in enumerate(accepted, start=1):
        logger.write(f"[{idx}] {src.get('title')} | {src.get('url')} | hits={src.get('keyword_hits')}")
    if rejected:
        logger.write(f"Rejected sources: {len(rejected)}")

    return {"keywords": keywords, "query": query, "accepted": accepted, "rejected": rejected, "error": ""}


# -----------------------------
# Model-output parsers
# -----------------------------


def parse_json_object(raw_text: str, default: dict[str, Any]) -> dict[str, Any]:
    if not raw_text:
        return dict(default)
    text = raw_text.strip()
    # Strip common markdown fences.
    text = re.sub(r"^```(?:json)?", "", text, flags=re.IGNORECASE).strip()
    text = re.sub(r"```$", "", text).strip()
    try:
        parsed = json.loads(text)
    except Exception:
        parsed = None
    if parsed is None:
        match = re.search(r"\{.*\}", text, re.DOTALL)
        if match:
            try:
                parsed = json.loads(match.group(0))
            except Exception:
                parsed = None
    if isinstance(parsed, dict):
        out = dict(default)
        out.update(parsed)
        return out
    return dict(default)


def parse_claude_checker(raw_text: str) -> dict[str, Any]:
    default = {
        "safe": "Y",
        "logic": "Y",
        "useful": "Y",
        "grounded": "Y",
        "decision": "GREENLIGHT",
        "note": "",
    }
    parsed = parse_json_object(raw_text, default)
    for key in ["safe", "logic", "useful", "grounded"]:
        parsed[key] = str(parsed.get(key, "Y")).upper()[:1]
        if parsed[key] not in {"Y", "N"}:
            parsed[key] = "Y"
    decision = str(parsed.get("decision", "GREENLIGHT")).upper().strip()
    if decision not in {"GREENLIGHT", "REVISE"}:
        decision = "REVISE" if "N" in {parsed["safe"], parsed["logic"], parsed["useful"], parsed["grounded"]} else "GREENLIGHT"
    parsed["decision"] = decision
    note = str(parsed.get("note", "")).strip()
    if len(note.split()) > 12:
        note = " ".join(note.split()[:12])
    parsed["note"] = note
    return parsed


def parse_gemini_ideas(raw_text: str) -> dict[str, Any]:
    default = {"ideas": []}
    parsed = parse_json_object(raw_text, default)
    ideas = parsed.get("ideas", [])
    if not isinstance(ideas, list):
        ideas = []
    ideas = [_clean_text(x) for x in ideas if _clean_text(x)][:5]
    if not ideas and raw_text:
        for line in raw_text.splitlines():
            cleaned = re.sub(r"^\s*\d+[\).:-]\s*", "", line).strip(" -*")
            if cleaned:
                ideas.append(cleaned)
            if len(ideas) >= 3:
                break
    return {"ideas": ideas[:5]}


# -----------------------------
# Provider calls
# -----------------------------


def _call_gemini_creative(config: dict, settings: dict, user_prompt: str, logger: TrinityDevLogger) -> tuple[dict[str, Any], str, str]:
    api_key = get_api_key(config, "gemini")
    try:
        import google.generativeai as genai
    except ImportError as exc:
        raise RuntimeError("google-generativeai package not installed. Run: pip install -r requirements.txt") from exc

    genai.configure(api_key=api_key)
    system_instruction = (
        "You are Gemini inside Trinity. Role: Creative Thinking / Idea Expansion only. "
        "Do not act as Claude or GPT. Do not write final answers. Return JSON only."
    )
    prompt = f"""User request:
{user_prompt}

Return ONLY valid JSON:
{{"ideas":["idea 1 under 12 words","idea 2 under 12 words","idea 3 under 12 words"]}}

Rules:
- You are Gemini only.
- Do not write as Claude, GPT, or another agent.
- No markdown.
- No final answer.
- Each idea must be short and useful.
"""
    logger.section("GEMINI CREATIVE ADVISOR")
    logger.block("Prompt sent to Gemini", prompt)

    last_error = None
    for model_name in settings["gemini_models"]:
        try:
            model = genai.GenerativeModel(model_name=model_name, system_instruction=system_instruction)
            response = model.generate_content(
                prompt,
                generation_config={
                    "max_output_tokens": settings["max_creative_tokens"],
                    "temperature": settings["temperature_creative"],
                },
                request_options={"timeout": 30},
            )
            try:
                raw_text = _clean_text(response.text)
            except Exception:
                raw_text = ""
            if not raw_text:
                raw_text = "{\"ideas\":[]}"
            ideas = parse_gemini_ideas(raw_text)
            logger.write(f"Model used: {model_name}")
            logger.block("Gemini raw visible output", raw_text)
            logger.block("Gemini parsed ideas", json.dumps(ideas, indent=2))
            return ideas, raw_text, model_name
        except Exception as exc:
            err = str(exc)
            last_error = err
            logger.write(f"Gemini model failed: {model_name} -> {err[:300]}")
            if _is_model_not_found(err) or _is_quota_error(err):
                continue
            break

    fallback = {"ideas": []}
    logger.block("Gemini fallback", f"Creative step unavailable: {str(last_error)[:300]}")
    return fallback, json.dumps(fallback), "unavailable"


def _call_anthropic_json(
    config: dict,
    settings: dict,
    prompt: str,
    logger: TrinityDevLogger,
    title: str,
) -> tuple[str, str, dict[str, Any]]:
    api_key = get_api_key(config, "anthropic")
    try:
        import anthropic
    except ImportError as exc:
        raise RuntimeError("anthropic package not installed. Run: pip install -r requirements.txt") from exc

    model_name = settings["anthropic_model"]
    client = anthropic.Anthropic(api_key=api_key, timeout=30.0)
    system = (
        "You are Claude inside Trinity. Role: concise reasoning, safety, and grounding checker. "
        "Do not write the final answer. Return only valid JSON."
    )
    logger.section(title)
    logger.block("Prompt sent to Claude", prompt)

    try:
        response = client.messages.create(
            model=model_name,
            max_tokens=settings["max_checker_tokens"],
            temperature=settings["temperature_checker"],
            system=system,
            messages=[{"role": "user", "content": prompt}],
        )
        parts = []
        for block in getattr(response, "content", []) or []:
            text = getattr(block, "text", None)
            if text:
                parts.append(text)
        raw_output = _clean_text("\n".join(parts))
        parsed = parse_claude_checker(raw_output)
        logger.write(f"Model used: {model_name}")
        logger.block("Claude raw visible output", raw_output or "[empty]")
        logger.block("Claude parsed checker JSON", json.dumps(parsed, indent=2))
        return raw_output, model_name, parsed
    except Exception as exc:
        err = str(exc)
        raw_output = "{\"safe\":\"Y\",\"logic\":\"Y\",\"useful\":\"N\",\"grounded\":\"N\",\"decision\":\"REVISE\",\"note\":\"Claude unavailable; answer cautiously.\"}"
        parsed = parse_claude_checker(raw_output)
        logger.block("Claude fallback output", f"[Claude checker unavailable: {err[:300]}]")
        logger.block("Claude parsed checker JSON", json.dumps(parsed, indent=2))
        return raw_output, "unavailable", parsed


def build_precheck_prompt(user_prompt: str, route: str, gemini_ideas: dict[str, Any] | None = None) -> str:
    return f"""Check the user request and advisory context.

Return ONLY valid JSON in this exact shape:
{{"safe":"Y","logic":"Y","useful":"Y","grounded":"Y","decision":"GREENLIGHT","note":""}}

Rules:
- No markdown. No explanation.
- safe, logic, useful, grounded must be "Y" or "N".
- decision must be "GREENLIGHT" or "REVISE".
- note must be 12 words max.
- Use REVISE only for a real issue.
- If factual sourcing is needed, grounded should be "N" unless sources exist.

Route: {route}
User request:
{user_prompt}

Gemini ideas, if any:
{json.dumps(gemini_ideas or {}, ensure_ascii=False)}
"""


def build_grounded_final_check_prompt(user_prompt: str, sources: list[dict[str, Any]], final_answer: str) -> str:
    source_brief = [
        {"title": s.get("title"), "url": s.get("url"), "keyword_hits": s.get("keyword_hits"), "snippet": s.get("snippet", "")[:400]}
        for s in sources
    ]
    return f"""Check whether the final answer stays grounded in the provided verified source snippets.

Return ONLY valid JSON:
{{"safe":"Y","logic":"Y","useful":"Y","grounded":"Y","decision":"GREENLIGHT","note":""}}

Rules:
- No markdown. No explanation.
- grounded = "N" if the answer makes specific unsupported factual claims.
- note must be 12 words max.

User request:
{user_prompt}

Verified sources:
{json.dumps(source_brief, ensure_ascii=False)}

Final answer:
{final_answer}
"""


def _call_openai(
    config: dict,
    settings: dict,
    system: str,
    prompt: str,
    logger: TrinityDevLogger,
    section_title: str,
    max_tokens: int | None = None,
) -> tuple[str, str]:
    api_key = get_api_key(config, "openai")
    try:
        import openai
    except ImportError as exc:
        raise RuntimeError("openai package not installed. Run: pip install -r requirements.txt") from exc

    model_name = settings["openai_model"]
    client = openai.OpenAI(api_key=api_key, timeout=45.0)
    logger.section(section_title)
    logger.block("Prompt sent to GPT/OpenAI", prompt)

    try:
        response = client.chat.completions.create(
            model=model_name,
            max_tokens=max_tokens or settings["max_final_tokens"],
            temperature=settings["temperature_final"],
            messages=[{"role": "system", "content": system}, {"role": "user", "content": prompt}],
        )
        output = _clean_text(response.choices[0].message.content) or "[OpenAI returned no usable text.]"
        logger.write(f"Model used: {model_name}")
        logger.block("GPT/OpenAI visible output", output)
        return output, model_name
    except Exception as exc:
        output = f"[OpenAI step unavailable: {str(exc)[:300]}]"
        logger.block("OpenAI fallback output", output)
        return output, "unavailable"


# -----------------------------
# Prompt builders
# -----------------------------


def source_context_text(grounding: dict[str, Any]) -> str:
    sources = grounding.get("accepted", []) or []
    if not sources:
        return "No verified sources were accepted by Python. Avoid specific unsupported factual claims."
    lines = []
    for i, s in enumerate(sources, start=1):
        lines.append(f"[{i}] {s.get('title')}\nURL: {s.get('url')}\nVerified keyword hits: {', '.join(s.get('keyword_hits', []))}\nSnippet: {s.get('snippet', '')[:900]}")
    return "\n\n".join(lines)


def build_python_brief(route: str, reason: str, keywords: list[str] | None = None, claude_check: dict[str, Any] | None = None) -> str:
    lines = [
        "Python orchestration brief:",
        f"- Selected route: {route}",
        f"- Routing reason: {reason}",
        "- Python handles routing, tools, source checks, CSV retention, logging, and fallbacks.",
        "- Models are advisors/writers inside Python's controlled workflow.",
    ]
    if keywords:
        lines.append(f"- Session keywords: {', '.join(keywords[:10])}")
    if claude_check:
        lines.append(f"- Claude decision parsed by Python: {claude_check.get('decision', 'UNKNOWN')}")
        if claude_check.get("note"):
            lines.append(f"- Claude note: {claude_check['note']}")
    return "\n".join(lines)


def build_final_prompt(
    user_prompt: str,
    route: str,
    python_brief: str,
    grounding: dict[str, Any] | None = None,
    gemini_ideas: dict[str, Any] | None = None,
    claude_check: dict[str, Any] | None = None,
    math_result: str | None = None,
) -> str:
    grounded_context = source_context_text(grounding or {"accepted": []}) if route == "grounded" else ""
    return f"""User request:
{user_prompt}

{python_brief}

Route-specific context:
- Route: {route}
- Math/tool result: {math_result or 'none'}
- Gemini creative ideas: {json.dumps(gemini_ideas or {}, ensure_ascii=False)}
- Claude checker JSON: {json.dumps(claude_check or {}, ensure_ascii=False)}

Verified source context, if this is a grounded route:
{grounded_context}

Final answer rules:
- Answer the user directly.
- Do not mention internal model roles unless the user directly asks about Trinity.
- If verified sources are provided, use only those for factual claims and include a small Sources section with URLs.
- If sources are missing or weak, say the answer is based on general interpretation and avoid specific unsupported claims.
- For creative outputs, use Gemini ideas as optional inspiration, not as facts.
- For flowcharts/diagrams, prefer Mermaid syntax when useful.
- Keep the answer practical and clear.
"""


# -----------------------------
# Flow runners
# -----------------------------


def _run_simple_flow(config: dict, settings: dict, user_input: str, routing_reason: str, logger: TrinityDevLogger, active: list[str], store: SessionCSVStore) -> str:
    started = time.time()
    keywords = extract_keywords(user_input)
    for kw in keywords:
        store.remember("keyword", kw, "python")
    logger.section("NEW USER PROMPT")
    logger.block("User prompt", user_input)
    logger.section("PYTHON ROUTING DECISION")
    logger.write("Route: simple")
    logger.write(f"Reason: {routing_reason}")
    logger.write("Python skipped Gemini and Claude to save cost.")
    print("\n[Trinity] Python route: simple/cheap mode")

    if "openai" not in active:
        return "[Simple mode needs OpenAI valid. No fallback selected for V1.5.]"
    system = "You are GPT inside Trinity. Give a concise direct answer."
    prompt = f"Answer the user directly and concisely.\n\nUser request:\n{user_input}"
    output, model = _call_openai(config, settings, system, prompt, logger, "SIMPLE MODE - GPT DIRECT", max_tokens=min(settings["max_final_tokens"], 250))
    elapsed = time.time() - started
    store.log_tool("simple_gpt", "ok", f"model={model}", elapsed)
    logger.section("ROUTING SUMMARY")
    logger.write(f"Route: simple | Model: {model} | Elapsed seconds: {elapsed:.2f}")
    return output


def _run_math_flow(config: dict, settings: dict, user_input: str, routing_reason: str, logger: TrinityDevLogger, active: list[str], store: SessionCSVStore) -> str:
    started = time.time()
    logger.section("NEW USER PROMPT")
    logger.block("User prompt", user_input)
    logger.section("PYTHON ROUTING DECISION")
    logger.write("Route: math_tool")
    logger.write(f"Reason: {routing_reason}")
    print("\n[Trinity] Python route: math/tool mode")

    try:
        math_result = safe_calculate(user_input)
        store.log_tool("safe_calculator", "ok", math_result, time.time() - started)
        logger.block("Python math result", math_result)
    except Exception as exc:
        math_result = f"Calculator could not safely solve this: {exc}"
        store.log_tool("safe_calculator", "error", math_result, time.time() - started)
        logger.block("Python math error", math_result)

    if "openai" in active:
        brief = build_python_brief("math_tool", routing_reason, extract_keywords(user_input))
        prompt = build_final_prompt(user_input, "math_tool", brief, math_result=math_result)
        output, _model = _call_openai(config, settings, "Explain Python tool results briefly.", prompt, logger, "GPT EXPLAINS TOOL RESULT", max_tokens=250)
    else:
        output = math_result
    logger.section("ROUTING SUMMARY")
    logger.write(f"Route: math_tool | Elapsed seconds: {time.time() - started:.2f}")
    return output


def _run_grounded_flow(config: dict, settings: dict, user_input: str, routing_reason: str, logger: TrinityDevLogger, active: list[str], store: SessionCSVStore) -> str:
    started = time.time()
    logger.section("NEW USER PROMPT")
    logger.block("User prompt", user_input)
    logger.section("PYTHON ROUTING DECISION")
    logger.write("Route: grounded")
    logger.write(f"Reason: {routing_reason}")
    logger.write("Python will run source tools, verify URLs, then send accepted snippets to GPT.")
    print("\n[Trinity] Python route: grounded/source mode")
    print("[Trinity] Tooling: extracting keywords + searching/fetching/verifying sources...")

    grounding = collect_grounding_sources(user_input, settings, store, logger)
    keywords = grounding.get("keywords", [])
    for kw in keywords:
        store.remember("keyword", kw, "python")
    for src in grounding.get("accepted", []):
        store.remember("source", src.get("url", ""), "python")

    claude_pre = {"safe": "Y", "logic": "Y", "useful": "Y", "grounded": "Y" if grounding.get("accepted") else "N", "decision": "GREENLIGHT" if grounding.get("accepted") else "REVISE", "note": "Use verified sources only."}
    brief = build_python_brief("grounded", routing_reason, keywords, claude_pre)
    prompt = build_final_prompt(user_input, "grounded", brief, grounding=grounding, claude_check=claude_pre)
    print("[Trinity] Step 1/2: GPT source-grounded final draft...")
    final_output, openai_model = _call_openai(
        config, settings,
        "You are GPT inside Trinity. Write source-grounded answers from Python-verified snippets only.",
        prompt, logger, "GPT SOURCE-GROUNDED FINAL", max_tokens=settings["max_final_tokens"]
    )

    claude_model = "skipped"
    claude_check = claude_pre
    if "anthropic" in active and settings.get("use_claude_grounded_checker", True):
        print("[Trinity] Step 2/2: Claude short grounding checker...")
        checker_prompt = build_grounded_final_check_prompt(user_input, grounding.get("accepted", []), final_output)
        _raw, claude_model, claude_check = _call_anthropic_json(config, settings, checker_prompt, logger, "CLAUDE FINAL GROUNDING CHECK")
        if claude_check.get("decision") == "REVISE" or claude_check.get("grounded") == "N":
            # Cheap correction pass only when necessary.
            correction_brief = build_python_brief("grounded", routing_reason, keywords, claude_check)
            correction_prompt = build_final_prompt(user_input, "grounded", correction_brief, grounding=grounding, claude_check=claude_check)
            final_output, openai_model = _call_openai(
                config, settings,
                "Revise the answer to remove unsupported factual claims. Use verified snippets only.",
                correction_prompt, logger, "GPT REVISION AFTER CLAUDE CHECK", max_tokens=settings["max_final_tokens"]
            )

    elapsed = time.time() - started
    logger.section("ROUTING SUMMARY")
    logger.write(f"Route: grounded | OpenAI model: {openai_model} | Claude model: {claude_model}")
    logger.write(f"Accepted sources: {len(grounding.get('accepted', []))}")
    logger.write(f"Elapsed seconds: {elapsed:.2f}")
    return final_output


def _run_creative_flow(config: dict, settings: dict, user_input: str, routing_reason: str, logger: TrinityDevLogger, active: list[str], store: SessionCSVStore) -> str:
    started = time.time()
    logger.section("NEW USER PROMPT")
    logger.block("User prompt", user_input)
    logger.section("PYTHON ROUTING DECISION")
    logger.write("Route: creative")
    logger.write(f"Reason: {routing_reason}")
    logger.write("Python will use Gemini because this request needs imagination/creative expansion.")
    print("\n[Trinity] Python route: creative/imagination mode")

    keywords = extract_keywords(user_input)
    for kw in keywords:
        store.remember("keyword", kw, "python")

    gemini_ideas = {"ideas": []}
    gemini_model = "skipped"
    if "gemini" in active:
        print("[Trinity] Step 1/3: Gemini creative advisor...")
        gemini_ideas, _gemini_raw, gemini_model = _call_gemini_creative(config, settings, user_input, logger)
    else:
        logger.write("Gemini unavailable; continuing without creative advisor.")

    claude_check = {"safe": "Y", "logic": "Y", "useful": "Y", "grounded": "Y", "decision": "GREENLIGHT", "note": ""}
    claude_model = "skipped"
    if "anthropic" in active:
        print("[Trinity] Step 2/3: Claude JSON checker...")
        checker_prompt = build_precheck_prompt(user_input, "creative", gemini_ideas)
        _raw, claude_model, claude_check = _call_anthropic_json(config, settings, checker_prompt, logger, "CLAUDE CREATIVE CHECK")

    brief = build_python_brief("creative", routing_reason, keywords, claude_check)
    prompt = build_final_prompt(user_input, "creative", brief, gemini_ideas=gemini_ideas, claude_check=claude_check)
    print("[Trinity] Step 3/3: GPT lead final response...")
    final_output, openai_model = _call_openai(
        config, settings,
        "You are GPT inside Trinity. Use Gemini's creative ideas and Claude's check to produce the final answer.",
        prompt, logger, "GPT CREATIVE FINAL", max_tokens=settings["max_final_tokens"]
    )
    elapsed = time.time() - started
    logger.section("ROUTING SUMMARY")
    logger.write(f"Route: creative | Gemini model: {gemini_model} | Claude model: {claude_model} | OpenAI model: {openai_model}")
    logger.write(f"Elapsed seconds: {elapsed:.2f}")
    return final_output


def _run_standard_flow(config: dict, settings: dict, user_input: str, routing_reason: str, logger: TrinityDevLogger, active: list[str], store: SessionCSVStore) -> str:
    started = time.time()
    logger.section("NEW USER PROMPT")
    logger.block("User prompt", user_input)
    logger.section("PYTHON ROUTING DECISION")
    logger.write("Route: standard")
    logger.write(f"Reason: {routing_reason}")
    logger.write("Python skips Gemini. Claude checks direction, GPT writes final.")
    print("\n[Trinity] Python route: standard GPT+Claude mode")

    keywords = extract_keywords(user_input)
    for kw in keywords:
        store.remember("keyword", kw, "python")

    claude_check = {"safe": "Y", "logic": "Y", "useful": "Y", "grounded": "Y", "decision": "GREENLIGHT", "note": ""}
    claude_model = "skipped"
    if "anthropic" in active:
        print("[Trinity] Step 1/2: Claude JSON checker...")
        checker_prompt = build_precheck_prompt(user_input, "standard", None)
        _raw, claude_model, claude_check = _call_anthropic_json(config, settings, checker_prompt, logger, "CLAUDE STANDARD CHECK")

    brief = build_python_brief("standard", routing_reason, keywords, claude_check)
    prompt = build_final_prompt(user_input, "standard", brief, claude_check=claude_check)
    print("[Trinity] Step 2/2: GPT lead final response...")
    final_output, openai_model = _call_openai(
        config, settings,
        "You are GPT inside Trinity. Produce the final answer based on Python's brief and Claude's check.",
        prompt, logger, "GPT STANDARD FINAL", max_tokens=settings["max_final_tokens"]
    )
    elapsed = time.time() - started
    logger.section("ROUTING SUMMARY")
    logger.write(f"Route: standard | Claude model: {claude_model} | OpenAI model: {openai_model}")
    logger.write(f"Elapsed seconds: {elapsed:.2f}")
    return final_output


# -----------------------------
# Shell entry
# -----------------------------


def start_shell(config: dict, activation_results: dict) -> None:
    settings = _get_trinity_settings(config)
    active = _active_valid_providers(config, activation_results)
    store = SessionCSVStore(str(settings.get("data_folder") or "data"))

    print(f"{Color.BOLD}{Color.CYAN}── TrinityFlow V1.5 ────────────────────────────{Color.RESET}")
    print("Type a prompt and press Enter.")
    print("Commands: exit, quit, q")
    print("Modes: auto routing, /cheap, /grounded, /creative, /full, /math")
    print(f"{Color.BOLD}────────────────────────────────────────────────{Color.RESET}\n")

    print(f"[Trinity] Active valid providers: {', '.join(active) if active else 'none'}")
    print(f"[Trinity] OpenAI lead model: {settings['openai_model']}")
    print(f"[Trinity] Claude checker model: {settings['anthropic_model']}")
    print(f"[Trinity] Gemini creative-only models: {', '.join(settings['gemini_models'])}")
    print(f"[Trinity] Config mode: {settings.get('mode', 'auto')}")
    print(f"[Trinity] CSV data folder: {settings.get('data_folder', 'data')}\n")

    if not active:
        print("[Trinity] No valid providers available for shell mode.")
        return
    if "openai" not in active:
        print("[Trinity Warning] V1.5 expects OpenAI as lead. Add a valid OpenAI key for best results.\n")

    while True:
        user_input = input("[You] > ").strip()

        if user_input.lower() in EXIT_COMMANDS:
            dump_path = store.dump_on_exit()
            print("\n[Trinity] Closing TrinityFlow shell.")
            print(f"[Trinity] Session memory dumped to: {dump_path}")
            break

        if not user_input:
            continue

        route, cleaned_prompt, routing_reason = classify_task(user_input, settings)
        if not cleaned_prompt:
            print("[Trinity] Empty prompt after command. Try again.")
            continue

        logger = TrinityDevLogger(log_folder=str(settings.get("log_folder") or "logs"), enabled=bool(settings.get("dev_log", True)))

        try:
            if route == "simple":
                final_output = _run_simple_flow(config, settings, cleaned_prompt, routing_reason, logger, active, store)
            elif route == "math_tool":
                final_output = _run_math_flow(config, settings, cleaned_prompt, routing_reason, logger, active, store)
            elif route == "grounded":
                final_output = _run_grounded_flow(config, settings, cleaned_prompt, routing_reason, logger, active, store)
            elif route == "creative":
                final_output = _run_creative_flow(config, settings, cleaned_prompt, routing_reason, logger, active, store)
            else:
                final_output = _run_standard_flow(config, settings, cleaned_prompt, routing_reason, logger, active, store)

            print("\n[Trinity Final]")
            print(final_output)
        except Exception as exc:
            error_text = str(exc)
            logger.section("UNHANDLED ERROR")
            logger.write(error_text)
            if _is_quota_error(error_text):
                print("[Trinity Quota Warning]")
                print("A provider is connected, but quota/rate limits blocked the request.")
            else:
                print("[Trinity Error]")
                print(error_text)

        if logger.path:
            print(f"\n[Trinity] Dev log saved to: {logger.path}")
            if os.name == "nt":
                print("[Trinity] Open it with Notepad to inspect visible routing/tools/model outputs.")
        print("\n" + "-" * 55 + "\n")
