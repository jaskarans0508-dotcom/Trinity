"""
Trinity Status
Defines provider status states and terminal display helpers.
"""

from enum import Enum


class ProviderStatus(Enum):
    MISSING  = "MISSING"   # No key found in config
    UNTESTED = "UNTESTED"  # Key present but not yet validated
    VALID    = "VALID"     # Key tested and working
    INVALID  = "INVALID"   # Key tested and rejected by provider
    ERROR    = "ERROR"     # Key present but unexpected error during test
    DISABLED = "DISABLED"  # Provider manually disabled in config


# Terminal color codes
class Color:
    RESET   = "\033[0m"
    RED     = "\033[91m"
    GREEN   = "\033[92m"
    YELLOW  = "\033[93m"
    CYAN    = "\033[96m"
    GREY    = "\033[90m"
    BOLD    = "\033[1m"


STATUS_COLORS = {
    ProviderStatus.MISSING:  Color.RED,
    ProviderStatus.UNTESTED: Color.GREY,
    ProviderStatus.VALID:    Color.GREEN,
    ProviderStatus.INVALID:  Color.RED,
    ProviderStatus.ERROR:    Color.YELLOW,
    ProviderStatus.DISABLED: Color.GREY,
}

# Trinity role assignments
PROVIDER_ROLES = {
    "openai":    "Lead / Primary Orchestrator",
    "anthropic": "Reasoning + Safety Checker",
    "gemini":    "Creative Thinking",
}

PROVIDER_DISPLAY = {
    "openai":    "OpenAI",
    "anthropic": "Anthropic / Claude",
    "gemini":    "Google Gemini",
}


def format_status_line(provider: str, status: ProviderStatus, note: str = "") -> str:
    """Return a formatted terminal line for one provider's status."""
    color  = STATUS_COLORS.get(status, Color.RESET)
    role   = PROVIDER_ROLES.get(provider, "Unknown")
    name   = PROVIDER_DISPLAY.get(provider, provider.title())
    label  = f"{color}{status.value:<10}{Color.RESET}"
    note_str = f"  {Color.GREY}({note}){Color.RESET}" if note else ""
    return f"  {label}  {Color.BOLD}{name:<22}{Color.RESET}  [{role}]{note_str}"


def print_trinity_header():
    print(f"\n{Color.BOLD}{Color.CYAN}╔══════════════════════════════╗")
    print(f"║        T R I N I T Y        ║")
    print(f"║   Multi-Provider AI Shell   ║")
    print(f"╚══════════════════════════════╝{Color.RESET}\n")


def print_status_report(results: dict):
    """
    results: { "openai": (ProviderStatus, note_str), ... }
    """
    print(f"{Color.BOLD}── Provider Status ─────────────────────────────{Color.RESET}")
    for provider in ["openai", "anthropic", "gemini"]:
        status, note = results.get(provider, (ProviderStatus.MISSING, ""))
        print(format_status_line(provider, status, note))
    print(f"{Color.BOLD}────────────────────────────────────────────────{Color.RESET}\n")


def print_missing_warning(missing_providers: list):
    """Tell the user exactly which keys still need to be added."""
    if not missing_providers:
        return
    names = [PROVIDER_DISPLAY.get(p, p) for p in missing_providers]
    print(f"{Color.YELLOW}[!] The following API keys are missing from config/api_keys.json:{Color.RESET}")
    for name in names:
        print(f"     • {name}")
    print(f"\n{Color.CYAN}    Open config/api_keys.json in Notepad or VS Code,")
    print(f"    paste your keys, save the file, and run Trinity again.{Color.RESET}\n")
