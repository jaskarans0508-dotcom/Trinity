"""
Trinity — Anthropic / Claude Provider
Role: Reasoning + Safety Checker
Validates the Anthropic key with a 1-token completion request.
"""

from core.status import ProviderStatus

REQUEST_TIMEOUT_SECONDS = 10.0
DEFAULT_MODEL = "claude-haiku-4-5-20251001"


def validate_anthropic(api_key: str) -> tuple[ProviderStatus, str]:
    """
    Test the Anthropic key with the smallest practical message request.
    Returns (ProviderStatus, note_string).
    Never prints the full key.
    """
    try:
        import anthropic
    except ImportError:
        return ProviderStatus.ERROR, "anthropic package not installed — run: pip install anthropic"

    try:
        client = anthropic.Anthropic(api_key=api_key, timeout=REQUEST_TIMEOUT_SECONDS)
        client.messages.create(
            model=DEFAULT_MODEL,
            max_tokens=1,
            messages=[{"role": "user", "content": "Hi"}]
        )
        return ProviderStatus.VALID, "connected"

    except anthropic.AuthenticationError:
        return ProviderStatus.INVALID, "key rejected by Anthropic"

    except anthropic.PermissionDeniedError:
        return ProviderStatus.INVALID, "permission denied or model not available"

    except anthropic.NotFoundError:
        return ProviderStatus.ERROR, f"model not found: {DEFAULT_MODEL}"

    except anthropic.RateLimitError:
        return ProviderStatus.VALID, "connected (rate limited)"

    except anthropic.APIConnectionError:
        return ProviderStatus.ERROR, "network error — check connection"

    except TimeoutError:
        return ProviderStatus.ERROR, "request timed out"

    except Exception as e:
        short = str(e)[:120]
        return ProviderStatus.ERROR, f"unexpected error: {short}"
