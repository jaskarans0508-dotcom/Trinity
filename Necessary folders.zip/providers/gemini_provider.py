"""
Trinity — Google Gemini Provider
Role: Creative Thinking / Idea Expansion
Validates the Gemini key with a minimal generate_content call.
"""

from core.status import ProviderStatus

REQUEST_TIMEOUT_SECONDS = 10
DEFAULT_MODELS = [
    "gemini-2.5-flash-lite",
    "gemini-1.5-flash-latest",
    "gemini-2.5-flash",
    "gemini-2.0-flash",
]


def validate_gemini(api_key: str) -> tuple[ProviderStatus, str]:
    """
    Test the Gemini key with the smallest practical generate request.
    Returns (ProviderStatus, note_string).
    Never prints the full key.
    """
    try:
        import google.generativeai as genai
    except ImportError:
        return ProviderStatus.ERROR, "google-generativeai package not installed — run: pip install google-generativeai"

    try:
        genai.configure(api_key=api_key)

        last_model_error = None
        quota_limited = False

        for model_name in DEFAULT_MODELS:
            try:
                model = genai.GenerativeModel(model_name)
                response = model.generate_content(
                    "Hi",
                    generation_config={"max_output_tokens": 1},
                    request_options={"timeout": REQUEST_TIMEOUT_SECONDS},
                )
                # finish_reason 2 = SAFETY block — the key and model are still
                # working fine; the test prompt just got filtered.  Treat as valid.
                candidates = getattr(response, "candidates", None)
                if candidates:
                    finish_reason = getattr(candidates[0], "finish_reason", None)
                    if finish_reason == 2:
                        return ProviderStatus.VALID, f"connected ({model_name})"
                _ = response.text  # Confirm we got a real text response
                return ProviderStatus.VALID, f"connected ({model_name})"

            except Exception as model_error:
                err = str(model_error).lower()
                last_model_error = str(model_error)

                if "api key not valid" in err or "invalid api key" in err or "api_key_invalid" in err:
                    return ProviderStatus.INVALID, "key rejected by Google"

                if "permission" in err or "denied" in err:
                    return ProviderStatus.INVALID, "permission denied"

                if "quota" in err or "rate" in err or "resource exhausted" in err or "429" in err:
                    quota_limited = True
                    continue

                if "not found" in err or "404" in err or "not supported" in err:
                    continue

                if "deadline" in err or "timeout" in err or "timed out" in err:
                    return ProviderStatus.ERROR, "request timed out"

                if "connection" in err or "network" in err:
                    return ProviderStatus.ERROR, "network error — check connection"

                short = str(model_error)[:120]
                return ProviderStatus.ERROR, f"unexpected error: {short}"

        if quota_limited:
            return ProviderStatus.VALID, "connected (quota limited)"

        return ProviderStatus.ERROR, f"no Gemini model worked: {str(last_model_error)[:120]}"

    except Exception as e:
        short = str(e)[:120]
        return ProviderStatus.ERROR, f"unexpected error: {short}"
