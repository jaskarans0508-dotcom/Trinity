"""
Trinity — OpenAI Provider
Role: Lead / Primary Orchestrator
Validates the OpenAI key with the smallest possible API call.
"""

from core.status import ProviderStatus

REQUEST_TIMEOUT_SECONDS = 10.0


def validate_openai(api_key: str) -> tuple[ProviderStatus, str]:
    """
    Test the OpenAI key by listing available models.
    Returns (ProviderStatus, note_string).
    Never prints the full key.
    """
    try:
        import openai
    except ImportError:
        return ProviderStatus.ERROR, "openai package not installed — run: pip install openai"

    try:
        client = openai.OpenAI(api_key=api_key, timeout=REQUEST_TIMEOUT_SECONDS)
        # Cheap validation call — lists models and consumes no generation tokens.
        models = client.models.list()
        _ = [m.id for m in models.data][:1]  # Confirm iterable response
        return ProviderStatus.VALID, "connected"

    except openai.AuthenticationError:
        return ProviderStatus.INVALID, "key rejected by OpenAI"

    except openai.PermissionDeniedError:
        return ProviderStatus.INVALID, "permission denied"

    except openai.RateLimitError:
        # Key format/auth is likely okay, but account/project is currently limited.
        return ProviderStatus.VALID, "connected (rate limited)"

    except openai.APIConnectionError:
        return ProviderStatus.ERROR, "network error — check connection"

    except TimeoutError:
        return ProviderStatus.ERROR, "request timed out"

    except Exception as e:
        short = str(e)[:120]
        return ProviderStatus.ERROR, f"unexpected error: {short}"
